# Initial env
rm(list = ls())
graphics.off()

###install.packages("MASS")
# Loading package
library(MASS)
data(Boston)

# a) Make pairwise scatterplots of the predictors, and describe your findings. 
pairs(Boston)

# b) Are any of the predictors associated with per capita crime rate? 
cor(Boston$crim,Boston)

# c) Do any of the suburbs of Boston appear to have particularly high crime rates? Tax rates? Pupil-teacher ratios? Comment on the range of each predictor. 
hist(Boston$crim, breaks =20)
quantile(Boston$crim, c(0, 0.5, 0.75, 0.90, 0.95, 1))
length(Boston$crim[Boston$crim>80])/length(Boston$crim)
# d) In this data set, how many of the suburbs average more than seen rooms per dwelling? More than eight rooms per dwelling? Comment on the suburbs that average more than eight rooms per dwelling. 